<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$user = current_user();
$cur = basename($_SERVER['PHP_SELF']);
$page_seo = $page_seo ?? ['title'=>'Admin · Vivid Lanka'];
require __DIR__ . '/../includes/seo.php';
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><?= seo_head($page_seo) ?>
<link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>"></head>
<body>
<div class="admin-shell">
  <aside class="admin-side">
    <p class="brand" style="color:#fff; margin-bottom:2rem">Vivid <span style="color:var(--gold); font-style:italic">Lanka</span></p>
    <a href="<?= e(url('admin/index.php')) ?>"     class="<?= $cur==='index.php'?'active':'' ?>">Overview</a>
    <a href="<?= e(url('admin/artworks.php')) ?>"  class="<?= $cur==='artworks.php'?'active':'' ?>">Artworks</a>
    <a href="<?= e(url('admin/orders.php')) ?>"    class="<?= $cur==='orders.php'?'active':'' ?>">Orders</a>
    <a href="<?= e(url('admin/testimonials.php')) ?>" class="<?= $cur==='testimonials.php'?'active':'' ?>">Testimonials</a>
    <a href="<?= e(url('admin/feedback.php')) ?>" class="<?= $cur==='feedback.php'?'active':'' ?>">Feedback</a>
    <a href="<?= e(url('admin/analytics.php')) ?>" class="<?= $cur==='analytics.php'?'active':'' ?>">Analytics</a>
    <a href="<?= e(url('admin/users.php')) ?>"     class="<?= $cur==='users.php'?'active':'' ?>">Users</a>
    <div style="margin-top:3rem; border-top:1px solid rgba(255,255,255,.1); padding-top:1rem">
      <p style="color:#fff; font-size:.85rem; margin-bottom:.25rem"><?= e($user['name']) ?></p>
      <p style="color:rgba(255,255,255,.5); font-size:.75rem; margin-bottom:1rem"><?= e($user['role']) ?></p>
      <a href="<?= e(url('admin/logout.php')) ?>" style="color:var(--gold)">Sign out</a>
    </div>
  </aside>
  <main class="admin-main">
